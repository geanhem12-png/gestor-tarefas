# Funções partilhadas pelos scripts de aplicação (GitFlow com gh)
set -e
cd "$(dirname "$0")"
git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "ERRO: execute dentro da pasta do projeto."; exit 1; }
command -v gh >/dev/null || { echo "ERRO: o GitHub CLI (gh) não está instalado."; exit 1; }
for f in versoes 'aplicar-*.sh' funcoes.sh; do
  grep -qxF "$f" .git/info/exclude 2>/dev/null || echo "$f" >> .git/info/exclude
done

milestone() { gh api repos/:owner/:repo/milestones -f title="v$1" -f description="$2" --jq .number; }

abrir() {   # branch
  git checkout -q develop
  git pull -q origin develop
  git checkout -q -b "$1"
}

integrar() {   # branch titulo corpo issue
  git push -q -u origin "$1"
  PR=$(gh pr create --base develop --head "$1" --title "$2" --body "$3 Closes #$4" | grep -o '[0-9]*$')
  gh pr merge "$PR" --merge
  gh issue close "$4" --comment "Resolvido no PR #$PR" >/dev/null 2>&1 || true
  echo "  feature integrada (PR #$PR)"
}

lancar() {   # versao descricao numero_milestone
  V="$1"
  git checkout -q develop
  git pull -q origin develop
  git checkout -q -b "release/$V"
  cp "versoes/changelog-$V.md" CHANGELOG.md
  git add CHANGELOG.md
  git commit -q -m "docs: atualizar CHANGELOG para a versão $V"
  git push -q -u origin "release/$V"
  PR=$(gh pr create --base main --head "release/$V" --title "release: versão $V" --body "Fusão da versão $V em main." | grep -o '[0-9]*$')
  gh pr merge "$PR" --merge
  git checkout -q main
  git pull -q origin main
  git tag -a "v$V" -m "Versão $V: $2"
  git push -q origin "v$V"
  git checkout -q develop
  git merge -q --no-ff "release/$V" -m "merge: integrar release/$V em develop"
  git push -q origin develop
  gh api -X PATCH "repos/:owner/:repo/milestones/$3" -f state=closed >/dev/null
  echo "  release v$V publicada (PR #$PR)"
}

estado_inicial() {
  git checkout -q -f develop
  git branch -D feature/build-vite >/dev/null 2>&1 || true
  git pull -q origin develop
}
