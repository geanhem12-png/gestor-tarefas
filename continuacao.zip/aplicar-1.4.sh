#!/usr/bin/env bash
# Aplica a versão 1.4.0 (Vite). Requer Node.js. Corre o build e mede a redução de tamanho.
source "$(dirname "$0")/funcoes.sh"
command -v npm >/dev/null || { echo "ERRO: o Node.js (npm) não está instalado."; exit 1; }
estado_inicial

echo "== v1.4.0: build com Vite =="
M=$(milestone 1.4.0 "Build de produção")
I=$(gh issue create --title "Build de produção com minificação" --label enhancement --milestone "v1.4.0" --body "Configurar Vite para compilar e minificar CSS e JS." | grep -o '[0-9]*$')
abrir feature/build-vite
cp -r versoes/v140/. .
npm install
npm run build

echo
echo "---------- MEDIÇÃO (use estes números na plataforma) ----------"
antes=$(cat index.html src/estilo.css src/app.js | wc -c)
depois=$(cat dist/index.html dist/assets/* | wc -c)
echo "Antes (index.html + estilo.css + app.js): $antes bytes"
echo "Depois (dist/index.html + dist/assets/*): $depois bytes"
echo "Redução total: $((100 - depois*100/antes))%"
echo "CSS: $(wc -c < src/estilo.css) -> $(cat dist/assets/*.css | wc -c) bytes"
echo "JS:  $(wc -c < src/app.js) -> $(cat dist/assets/*.js | wc -c) bytes"
echo "---------------------------------------------------------------"
echo

git add -A
git commit -q -m "build: adicionar Vite para empacotar e minificar CSS e JS"
integrar feature/build-vite "build: Vite e minificação" "Separa CSS e JS, adiciona package.json, vite.config.js e README atualizado." "$I"
lancar 1.4.0 "build com Vite" "$M"

echo
echo "Concluído: v1.4.0 publicada. Teste a página com: npm run preview"
git tag
