# Changelog

## [1.1.0]
### Adicionado
- Testes unitários (python -m unittest -v)
### Alterado
- README com URL de clonagem e secção de testes

## [1.0.1]
### Corrigido
- Validação de descrições vazias ao adicionar tarefas

## [1.0.0]
### Adicionado
- Criar, listar e concluir tarefas
- Interface de linha de comandos
