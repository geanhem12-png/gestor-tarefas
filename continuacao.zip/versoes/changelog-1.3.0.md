# Changelog

## [1.3.0]
### Adicionado
- Modo escuro (automático e manual)
### Corrigido
- Contraste do contorno de foco no tema claro

## [1.2.0]
### Adicionado
- Interface web acessível (index.html) com landmarks semânticos e WAI-ARIA

## [1.1.0]
### Adicionado
- Testes unitários (python -m unittest -v)
### Alterado
- README com URL de clonagem e secção de testes

## [1.0.1]
### Corrigido
- Validação de descrições vazias ao adicionar tarefas

## [1.0.0]
### Adicionado
- Criar, listar e concluir tarefas
- Interface de linha de comandos
