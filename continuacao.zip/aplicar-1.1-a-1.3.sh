#!/usr/bin/env bash
# Aplica as versões 1.1.0, 1.2.0 e 1.3.0 com GitFlow: milestone, issue, feature, PR, release, tag.
source "$(dirname "$0")/funcoes.sh"
estado_inicial

echo "== v1.1.0: testes e README =="
M=$(milestone 1.1.0 "Testes e README completo")
I=$(gh issue create --title "Adicionar testes e completar README" --label enhancement --milestone "v1.1.0" --body "Adicionar testes unitários e corrigir o README (URL de clonagem e secção de testes)." | grep -o '[0-9]*$')
abrir feature/testes-e-readme
cp versoes/v110/test_tarefas.py .
git add test_tarefas.py && git commit -q -m "test: adicionar testes unitários das tarefas"
cp versoes/v110/README.md .
git add README.md && git commit -q -m "docs: corrigir URL de clonagem e adicionar secção de testes no README"
integrar feature/testes-e-readme "test: testes unitários e README completo" "Adiciona test_tarefas.py e corrige o README." "$I"
lancar 1.1.0 "testes e README completo" "$M"

echo "== v1.2.0: interface web acessível =="
M=$(milestone 1.2.0 "Interface web acessível")
I=$(gh issue create --title "Interface web acessível" --label enhancement --milestone "v1.2.0" --body "Criar página web com landmarks semânticos e atributos WAI-ARIA." | grep -o '[0-9]*$')
abrir feature/acessibilidade-web
cp versoes/v120/index.html .
git add index.html && git commit -q -m "feat: adicionar interface web com HTML semântico e WAI-ARIA"
integrar feature/acessibilidade-web "feat: interface web acessível" "Adiciona index.html com header, nav, main, footer e WAI-ARIA." "$I"
lancar 1.2.0 "interface web acessível" "$M"

echo "== v1.3.0: modo escuro =="
M=$(milestone 1.3.0 "Modo escuro e contraste")
I=$(gh issue create --title "Modo escuro e contraste WCAG" --label enhancement --milestone "v1.3.0" --body "Adicionar tema escuro e garantir rácios de contraste WCAG." | grep -o '[0-9]*$')
abrir feature/modo-escuro
cp versoes/v130/index.html .
git add index.html && git commit -q -m "feat: adicionar modo escuro e corrigir contraste do foco"
integrar feature/modo-escuro "feat: modo escuro e contraste" "Variáveis CSS, prefers-color-scheme, botão de tema e foco corrigido." "$I"
lancar 1.3.0 "modo escuro" "$M"

echo
echo "Concluído: v1.1.0, v1.2.0 e v1.3.0 publicadas."
git tag
